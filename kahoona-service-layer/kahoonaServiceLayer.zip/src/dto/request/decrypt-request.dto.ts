export class DecryptRequestDto {
    encryptedData!: string
}