export interface BaseInterface {
  varString: string;
  varNumber: number;
}
