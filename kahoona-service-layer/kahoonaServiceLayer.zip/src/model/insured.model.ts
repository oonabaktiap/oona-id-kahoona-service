export interface Insured {
    type: string;
    value: string;
    name: string;
    dob: string;
    mobileNo: string;
    email: string;
    gender: string
    
};