export interface QuoteDetailsOtherData {
    isInsuredSmoker: boolean;
    deepLinkStage: string;
    questionAnswers: []
}