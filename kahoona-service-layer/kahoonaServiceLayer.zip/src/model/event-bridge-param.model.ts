export class EventBridgeParam {
    Source: any;
    DetailType: any;
    Detail: any;
    EventBusName: any;
    Time: Date;
}