export interface Workflow {
    role: string;
    createdBy: string;
    AgentProfileId: string
}