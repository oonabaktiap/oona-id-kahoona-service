export interface AdditionalBenefit {
    BenefitCode: string;
    BenefitDesc: string;
    BenefitType: string;
    DisplaySeqNo: number;
    ParentBenefit: string;
    Premium: string;
    SumInsured: string;
    signedUrl: string;
    selectbtn: boolean
}