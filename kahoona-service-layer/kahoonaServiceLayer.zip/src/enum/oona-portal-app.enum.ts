export enum OonaPortalAppEnum {
    KAHOONA = 1,
    DTC = 2,
    CHATBOT = 3,
}